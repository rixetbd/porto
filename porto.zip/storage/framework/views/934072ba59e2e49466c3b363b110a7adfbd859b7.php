<?php $__env->startSection('email_content'); ?>

<div class="card-body">

    <div>
        <div class="mb-3">
            <input type="email" class="form-control" placeholder="To">
        </div>

        <div class="mb-3">
            <input type="text" class="form-control" placeholder="Subject">
        </div>
        <div class="mb-3">
            <form method="post">
                <textarea id="elm1" name="area"></textarea>
            </form>
        </div>

        <div class="btn-toolbar mb-0">
            <div class="">
                <button type="button" class="btn btn-primary waves-effect waves-light me-1"><i class="far fa-save"></i></button>
                <button type="button" class="btn btn-primary waves-effect waves-light me-1"><i class="far fa-trash-alt"></i></button>
                <button class="btn btn-info waves-effect waves-light"> <span>Send</span> <i class="fab fa-telegram-plane ms-2"></i> </button>
            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.email.email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/admin/email/email_compose.blade.php ENDPATH**/ ?>