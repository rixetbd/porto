<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Trash</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Home Page</li>
                    <li class="breadcrumb-item active">Trash</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><h6>All Information</h6></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Heading</th>
                                <th>Starting</th>
                                <th style="min-width: 150px;">Skills Title</th>
                                <th>Description</th>
                                <th>Delete_At</th>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($value->heading); ?></td>
                                <td><?php echo e($value->starting); ?></td>
                                <td>
                                    <?php $__currentLoopData = explode(',', $value->skills); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($item); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo $value->description; ?></td>
                                <td><?php echo e($value->deleted_at->diffForhumans()); ?></td>

                                <td>
                                    <a class="btn btn-outline-success btn-sm edit m-1" title="Restore" href="<?php echo e(route('admin.homepage.restore', $value->id)); ?>">
                                        <i class="fas fa-redo"></i>
                                    </a>
                                    <a class="btn btn-outline-danger btn-sm edit m-1" title="Edit" href="<?php echo e(route('admin.homepage.forcedelete', $value->id)); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">Nothing For Show</td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><h6>Home Page Background</h6></div>
            <div class="card-body">
                <div>
                    <form action="<?php echo e(route('admin.homepage.bgcreate')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="image" class="form-control form-control-sm">
                        <button type="submit" class="btn btn-sm btn-success my-2">Upload</button>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Background Image</th>
                                <th>Delete At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $dataBG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td>
                                    <a class="image-popup-no-margins" href="<?php echo e(asset('uploads/bg')); ?>/<?php echo e($bg->image); ?>">
                                        <img src="<?php echo e(asset('uploads/bg')); ?>/<?php echo e($bg->image); ?>" alt="No Image" class="img-fluid" style="width:60px">
                                    </a>
                                </td>
                                <td><?php echo e($bg->deleted_at->diffForHumans()); ?></td>
                                <td>
                                    <a class="btn btn-outline-success btn-sm edit m-1" title="Restore" href="<?php echo e(route('admin.homepage.restoreBG', $bg->id)); ?>">
                                        <i class="fas fa-redo"></i>
                                    </a>

                                    <a class="btn btn-outline-danger btn-sm edit m-1" title="Force Delete" href="<?php echo e(route('admin.homepage.forcedeleteBG', $bg->id)); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nothing For Show</td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/admin/home_page/trash.blade.php ENDPATH**/ ?>