<?php $__env->startSection('email_content'); ?>
<div class="card-body">
    <div class="d-flex mb-4">
        <div class="flex-shrink-0 me-3">
            
            <i class="fas fa-user fa-3x"></i>
        </div>
        <div class="flex-grow-1">
            <h4 class="font-size-16"><?php echo e($mail_id->name); ?></h4>
            <p class="text-muted font-size-13"><?php echo e($mail_id->email); ?></p>
        </div>
    </div>
    <h4 class="font-size-16"><?php echo e($mail_id->subject); ?></h4>

    <p>Dear <?php echo e(Auth::user()->name); ?>,</p>
    <p><?php echo e($mail_id->message); ?></p>
    <hr/>

    <!-- Image Area -->
    

    <a href="email-compose.html" class="btn btn-secondary waves-effect mt-4"><i class="mdi mdi-reply"></i> Reply</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.email.email_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/admin/email/read_email.blade.php ENDPATH**/ ?>