<?php $__env->startSection('content'); ?>

<!-- Page Title Starts -->
<section class="title-section text-center text-sm-center revealator-slideup revealator-once revealator-delay1">
  <p class="utf-section-description">About Main Info</p>
  <h1>About <span>Me</span></h1>
  <div class="animated-bar"></div>
  
</section>
<!-- Page Title Ends -->

<!-- Main Content Starts -->
<section class="main-content revealator-slideup revealator-once revealator-delay1">
  <div class="container">
    <div class="row">
      <!-- Personal Info Starts -->
      <div class="col-12 col-lg-12 col-xl-12">
        <div class="row">
          <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 utf-about-user-img"> <img src="<?php echo e(asset('uploads/about')); ?>/<?php echo e(($basic_info != ''? $basic_info->picture:'no-image')); ?>" class="img-fluid main-img-mobile" alt="<?php echo e(($basic_info != ''? $basic_info->picture:'No Image')); ?>" /> </div>
		  <div class="row col-xl-7 col-lg-7 col-md-12 utf-about-dtl">
			  <div class="col-12 mb-3">
				<h2 class="mb-0">Hello, I'm <?php echo e(($basic_info != ''? $basic_info->name:'Not Added')); ?></h2>
                <h6><?php echo e(($basic_info != ''? $basic_info->designation:'Not Added')); ?></h6>
				<p>- It's My Pleasure to Introduce About Myself.</p>
				<?php echo ($basic_info != ''? $basic_info->description:'Not Added'); ?>

			  </div>
			  <div class="col-6">
				<ul class="utf-about-list list-unstyled">
				  <li><span class="title">Name :</span> <span class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e(($basic_info != ''? $basic_info->name:'Not Added')); ?></span></li>
				  <li><span class="title">Date of Birth :</span> <span class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e(($basic_info != ''? $basic_info->date:'Not Added')); ?></span></li>
				  <li><span class="title">Work Status :</span> <span class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e(($basic_info != ''? $basic_info->designation:'Not Added')); ?></span></li>
				</ul>
			  </div>
			  <div class="col-6">
				<ul class="utf-about-list list-unstyled">
				  <li><span class="title">Email :</span> <span class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e(($basic_info != ''? $basic_info->email:'Not Added')); ?></span></li>
				  <li><span class="title">Phone :</span> <span class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e(($basic_info != ''? $basic_info->phone:'Not Added')); ?></span></li>
                  <li><span class="title">Nationality :</span> <span class="value d-block d-sm-inline-block d-lg-block d-xl-inline-block"><?php echo e(($basic_info != ''? $basic_info->nationality:'Not Added')); ?></span></li>
				</ul>
			  </div>
			  <div class="col-12 mt-3">
				<a href="<?php echo e(route('admin.downloadCVPdfFile')); ?>" class="btn btn-download">Download My CV <i class="fa fa-download"></i></a>

				<a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-hire">Hire Me! <i class="fa fa-file"></i></a>
			  </div>
		  </div>
        </div>
      </div>
      <!-- Personal Info Ends -->
      <!-- Boxes Starts -->
      <div class="col-12 col-lg-12 col-xl-12 pt-5 mt-lg-0 pb-5">
        <div class="row">
          <div class="col-6 col-lg-2 col-sm-4 col-xs-12">
            <div class="utf-box-stats with-margin">
			  <i class="fa fa-user"></i>
              <p class="m-0 position-relative"><?php echo e(($counter != ''?$counter->projects:'14+ Projects')); ?></p>
            </div>
          </div>
          <div class="col-6 col-lg-2 col-sm-4 col-xs-12">
            <div class="utf-box-stats with-margin">
			  <i class="fa fa-coffee"></i>
              <p class="m-0 position-relative"><?php echo e(($counter != ''?$counter->coffee:'140+ Coffee')); ?></p>
            </div>
          </div>
          <div class="col-6 col-lg-2 col-sm-4 col-xs-12">
            <div class="utf-box-stats with-margin">
			  <i class="fa fa-smile-o"></i>
              <p class="m-0 position-relative"><?php echo e(($counter != ''?$counter->clients:'9+ Clients')); ?></p>
            </div>
          </div>
          <div class="col-6 col-lg-2 col-sm-4 col-xs-12">
            <div class="utf-box-stats with-margin">
			  <i class="fa fa-certificate"></i>
              <p class="m-0 position-relative"><?php echo e(($counter != ''?$counter->exprience:'14+ Exprience')); ?></p>
            </div>
          </div>
		  <div class="col-6 col-lg-2 col-sm-4 col-xs-12">
            <div class="utf-box-stats with-margin">
			  <i class="fa fa-trophy"></i>
              <p class="m-0 position-relative"><?php echo e(($counter != ''?$counter->awards:'4+ Awards')); ?></p>
            </div>
          </div>
          <div class="col-6 col-lg-2 col-sm-4 col-xs-12">
            <div class="utf-box-stats with-margin">
			  <i class="fa fa-code"></i>
              <p class="m-0 position-relative"><?php echo e(($counter != ''?$counter->codes:'2500+ Codes')); ?></p>
            </div>
          </div>
        </div>
      </div>
      <!-- Boxes Ends -->
    </div>


    <!-- Skills Starts -->
    <div class="row pb-5">
        <div class="col-12">
            <h3 class="pb-5 pb-sm-5 mb-3 mb-sm-0 text-center text-sm-center custom-title ft-wt-600">My Skills</h3>
        </div>
      <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-lg-4 col-sm-6 col-xs-12 mb-3 mb-sm-4">
            <div class="utf-skills-box">
                <div class="c100 p<?php echo e($skill->performance); ?>"> <span><?php echo e($skill->performance); ?>%</span>
                <div class="slice">
                    <div class="bar"></div>
                    <div class="fill"></div>
                </div>
                </div>
                <h6 class="text-center mt-2 mt-sm-4 mb-0"><?php echo e($skill->subject); ?></h6>
                <p><?php echo e($skill->description); ?></p>
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="col-12 col-md-6 col-lg-6 col-xl-4 mb-30">
        <h5 class="alert alert-warning">Add some skills first.</h5>
        </div>
      <?php endif; ?>

    </div>
    <!-- Skills Ends -->

    <!-- Experience & Education Starts -->
    <div class="row">
      <div class="col-lg-6 m-15px-tb">
	    <h3 class="col-title">My Education</h3>
        <div class="utf-resume-box">
          <ul>
            <?php $__empty_1 = true; $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li>
              <div class="icon"></div>
              <span class="time"><?php echo e($edu->start_year); ?> - <?php echo e($edu->end_year); ?></span>
              <h5><?php echo e($edu->degree); ?> <span class="place"><?php echo e($edu->institute); ?></span></h5>
              <p><?php echo e($edu->description); ?></p>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>
                <h6 class="alert alert-warning">Add Your Educational Info</h6>
            </li>
            <?php endif; ?>

          </ul>
        </div>
      </div>
      <div class="col-lg-6 m-15px-tb">
	    <h3 class="col-title">My Experience</h3>
        <div class="utf-resume-box">
          <ul>
            <?php $__empty_1 = true; $__currentLoopData = $experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li>
              <div class="icon"></div>
              <span class="time"><?php echo e($item->start_year); ?> - <?php echo e($item->end_year); ?></span>
              <h5><?php echo e($item->position); ?> <span class="place"><?php echo e($item->organization); ?></span></h5>
              <p><?php echo e($item->description); ?></p>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>
                <h6 class="alert alert-warning">Add Your Educational Info</h6>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
    <!-- Experience & Education Ends -->

    <!-- Provide Services Starts -->
    <div class="row pb-3 pt-5 utf-services-section">
      <div class="col-12">
        <h3 class="pb-5 pb-sm-5 mb-3 mb-sm-0 text-center text-sm-center custom-title ft-wt-600">What Can I Do</h3>
      </div>
	  <?php $__empty_1 = true; $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	  <div class="col-12 col-md-6 col-lg-4">
		<div class="utf-single-service rc-mb-0"><i class="service-icon fa fa-bolt"></i>
		  <h6 class="utf-service-title"><?php echo e($item->title); ?></h6>
		  <p class="utf-service-description"><?php echo e(Str::limit($item->description, 150)); ?></p>
		</div>
	  </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="col-12">
        <h6 class="alert alert-warning">Add Your Services Info</h6>
      </div>
      <?php endif; ?>


    </div>
    <!-- Provide Services Ends -->

	<!-- Testimonials section Starts-->
    <div class="pb-3 pt-5 utf-testimonials-section utf-single-section">
      <div class="col-12">
        <h3 class="pb-5 pb-sm-5 mb-3 mb-sm-0 text-center text-sm-center custom-title ft-wt-600">Customer Testimonials</h3>
      </div>
	  <div class="utf-testimonial-slider">
		<?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="utf-slider-item">
		  <!-- Single review-->
		  <div class="utf-single-review utf-swiper-slide">
			<div class="utf-review-header d-flex justify-content-between">
			  <div class="utf-review-client">
				<div class="media"><img class="img-fluid rounded-circle client-avatar" src="<?php echo e(($testimonial->picture != ''?asset('uploads/clients/'.$testimonial->picture):asset('admin_assets/images/users/testimonials.png'))); ?>" alt="Client">
				  <div class="utf-client-details">
					<h6 class="utf-client-name"><?php echo e($testimonial->name); ?></h6>
					<span class="utf-client-role">Web Designer</span> </div>
				</div>
			  </div>
			  <i class="icon ion-md-quote review-icon"></i> </div>
			<p class="utf-client-review-content"><?php echo e($testimonial->description); ?></p>
		  </div>
		</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="utf-single-review utf-swiper-slid">
            <h5 class="alert alert-warning">Testimonial Not Founded!</h5>
        </div>
        <?php endif; ?>

	  </div>
    </div>
    <!-- Testimonials section Ends -->

	<!-- Choose Your Plan Starts -->
    <!-- Only visible in laravel -->
    
    <!-- Choose Your Plan Ends -->
  </div>
</section>
<!-- Main Content Ends -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_script'); ?>

<script>
    tns({
        container: ".utf-testimonials-section .utf-testimonial-slider",
        items: 2,
        gutter: 30,
        responsive: {
            0: {
                items: 1,
                gutter: 0
		},
		768: {
            items: 2,
			gutter: 30
		}
	},
	preventScrollOnTouch: "auto",
	slideBy: "page",
	mouseDrag: !0,
	swipeAngle: !1,
	speed: 400,
	controls: !1,
	autoHeight: !0,
	navPosition: "bottom"
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/frontend/about.blade.php ENDPATH**/ ?>