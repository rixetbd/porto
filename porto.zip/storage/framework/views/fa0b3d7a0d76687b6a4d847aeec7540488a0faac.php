<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Home Page</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">All Information</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><h6>All Information <span class="float-end"><a href="<?php echo e(route('admin.homepage.new')); ?>" class="btn btn-sm btn-success">Add New</a></span></h6></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Heading</th>
                                <th style="min-width: 100px;">Starting</th>
                                <th style="min-width: 150px;">Skills Title</th>
                                <th>Description</th>
                                <th>URL_Text</th>
                                <th>Status</th>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($value->heading); ?></td>
                                <td><?php echo e($value->starting); ?></td>
                                <td>
                                    <?php $__currentLoopData = explode(',', $value->skills); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($item); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo $value->description; ?></td>
                                <td>
                                    <?php echo e($value->btnOneText); ?><hr><?php echo e($value->btnTowText); ?>

                                </td>
                                <td>
                                    <?php if($value->status == 1): ?>
                                        <a class="btn status_btn" name="<?php echo e($value->id); ?>">
                                            <i class="fas fa-toggle-on fa-2x text-success"></i>
                                        </a>
                                    <?php else: ?>
                                        <a class="btn status_btn" name="<?php echo e($value->id); ?>">
                                            <i class="fas fa-toggle-off fa-2x text-danger"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <a class="btn btn-outline-secondary btn-sm edit m-1" title="Edit" href="<?php echo e(route('admin.homepage.edit', $value->id)); ?>">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>
                                    <a class="btn btn-outline-danger btn-sm edit m-1" title="Delete" href="<?php echo e(route('admin.homepage.softdelete', $value->id)); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center">Nothing For Show</td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><h6>Home Page Background</h6></div>
            <div class="card-body row">
                <div class="col-lg-3 mt-3">
                    <form action="<?php echo e(route('admin.homepage.bgcreate')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="image">Upload Image</label>
                        <input type="file" name="image" id="image" class="form-control form-control-sm">
                        <button type="submit" class="btn btn-sm btn-success my-2">Upload</button>
                    </form>
                </div>

                <div class="col-lg-9">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Background Image</th>
                                    <th>Upload At</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $dataBG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td>
                                        <a class="image-popup-no-margins" href="<?php echo e(asset('uploads/bg')); ?>/<?php echo e($bg->image); ?>">
                                            <img src="<?php echo e(asset('uploads/bg')); ?>/<?php echo e($bg->image); ?>" alt="No Image" class="img-fluid" style="width:60px">
                                        </a>
                                    </td>
                                    <td><?php echo e($bg->created_at->diffForHumans()); ?></td>
                                    <td>
                                        <?php if($bg->status == 1): ?>
                                            <a class="btn" href="<?php echo e(route('admin.homepage.statusbg', $bg->id)); ?>">
                                                <i class="fas fa-toggle-on fa-2x text-success"></i>
                                            </a>
                                        <?php else: ?>
                                            <a class="btn" href="<?php echo e(route('admin.homepage.statusbg', $bg->id)); ?>">
                                                <i class="fas fa-toggle-off fa-2x text-danger"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a class="btn btn-outline-danger btn-sm edit m-1" title="Trash" href="<?php echo e(route('admin.homepage.softdeleteBG', $bg->id)); ?>">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Nothing For Show</td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_script'); ?>

<script>
    $('.status_btn').click(function(){

        var id = $(this).attr('name');

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
               type:'POST',
               url:'/admin/homepage/status',
               data:{'id':id},
               success:function(data) {
                    // location.reload();
                    window.location.reload();
               }
        });

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/admin/home_page/index.blade.php ENDPATH**/ ?>