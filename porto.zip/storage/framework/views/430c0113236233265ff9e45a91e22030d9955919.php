<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">About</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">About</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">

    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6>About Page Info</h6>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Photo</th>
                            <th>Basic</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $basic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>1</td>
                            <td>
                                <a class="image-popup-no-margins" href="<?php echo e(asset('uploads/about')); ?>/<?php echo e($value->picture); ?>">
                                    <img src="<?php echo e(asset('uploads/about')); ?>/<?php echo e($value->picture); ?>" alt="No Image" class="img-fluid rounded" style="width: 80px;">
                                </a>
                            </td>
                            <td>
                                Name : <?php echo e($value->name); ?><br>
                                Designation : <?php echo e($value->designation); ?><br>
                                Email : <?php echo e($value->email); ?><br>
                                Date Of Birth : <?php echo e($value->date); ?><br>
                                Phone : <?php echo e($value->phone); ?><br>
                                Nationality : <?php echo e($value->nationality); ?><br>
                            </td>
                            <td><?php echo $value->description; ?></td>
                            <td>
                                <a class="btn status_btn" href="<?php echo e(route('admin.about.basic.status', $value->id)); ?>">
                                    <?php if($value->status == 1): ?>
                                        <i class="fas fa-toggle-on fa-2x text-success"></i>
                                    <?php else: ?>
                                        <i class="fas fa-toggle-off fa-2x text-danger"></i>
                                    <?php endif; ?>
                                </a>
                            </td>

                            <td>
                                <a class="btn btn-outline-danger btn-sm edit m-1" title="Delete" href="<?php echo e(route('admin.about.basic.delete', $value->id)); ?>">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center">
                            <td colspan="6">Nothing For Show</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6>Add About Page Info</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.about.new')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-6 mb-2">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="name" class="form-control form-control-sm">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 mb-2">
                        <label for="designation">Designation</label>
                        <input type="text" name="designation" id="designation" class="form-control form-control-sm">
                        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 mb-2">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="form-control form-control-sm">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 mb-2">
                        <label for="date">Date Of Birth</label>
                        <input type="date" name="date" id="date" class="form-control form-control-sm">
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 mb-2">
                        <label for="phone">Phone</label>
                        <input type="text" name="phone" id="phone" class="form-control form-control-sm">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 mb-2">
                        <label for="nationality">Nationality</label>
                        <input type="text" name="nationality" id="nationality" class="form-control form-control-sm">
                        <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="description">Description</label>
                    <textarea id="elm1" name="description"></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12 mb-2">
                    <label for="picture">Upload a photo</label>
                    <input type="file" name="picture" id="picture" class="form-control form-control-sm">
                    <?php $__errorArgs = ['picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" style="letter-spacing: 0.5px;"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <button type="submit" class="btn btn-sm btn-success">Add Info</button>
                </div>


                </form>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_script'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/admin/about/index.blade.php ENDPATH**/ ?>