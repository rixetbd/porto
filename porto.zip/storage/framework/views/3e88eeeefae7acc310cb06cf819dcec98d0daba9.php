<?php $__env->startSection('content'); ?>


  <!-- Page Title Starts -->
  <section class="title-section text-center text-sm-center revealator-slideup revealator-once revealator-delay1">
    <p class="utf-section-description">Portfolio</p>
    <h1>Portfolio Single <span>Post</span></h1>
    <div class="animated-bar"></div>
    <p class="text-max-700">Lorem ipsum dolor sit amet, consect adipisic elit, sed do eiusmod tempor incididunt ut labore et d magna aliqua enim sed do sit.</p>
  </section>
  <!-- Page Title Ends -->

  <!-- Main Content Starts -->
  <div class="main-content revealator-slideup revealator-once revealator-delay1">
    <div class="container">
      <div class="row">
        <!-- Article Starts -->
        <article class="col-12">
          <img src="<?php echo e(asset('uploads/portfolio')); ?>/<?php echo e($portfolio->thumbnail); ?>" class="img-fluid w-100 rounded" alt="Blog image"/>
          <h1 class="text-uppercase text-capitalize mt-3"><?php echo e($portfolio->title); ?></h1>
          <div class="meta">
              <span><i class="fa fa-user"></i> By, <?php echo e($portfolio->rel_to_user->name); ?></span>
              <span class="date mx-3"><i class="fa fa-calendar"></i> <?php echo e($portfolio->created_at->format(date('d-m-Y'))); ?></span>
              <span><i class="fa fa-tags"></i> <?php echo e($portfolio->technology); ?></span>
          </div>
        <div class="utf-blog-excerpt pb-2 my-4">
            <?php echo $portfolio->description; ?>

        </div>
          <!--  Comments Starts -->
          <div class="comments">
            <h3 class="utf-comments-heading"><?php echo e($portfolio_comment->count()); ?> Comments</h3>

            <?php $__empty_1 = true; $__currentLoopData = $portfolio_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <ul class="utf-comments-list p-0">
                <li>
                  <div class="comment pb-0"> <!-- <img class="comment-avatar pull-left" alt="" src="http://utouchdesign.com/themes/meetu/dark/img/user1.jpg"> -->
                    <i class="fa fa-user fa-4x comment-avatar pull-left"></i>
                    <div class="comment-body" style="margin-left: 75px;">
                      <div class="meta-data"> <span class="comment-author"><?php echo e($comment->viewer_name); ?></span> <span class="comment-date pull-right"><?php echo e($comment->created_at->format(date('d-m-Y'))); ?></span> </div>
                      <div class="comment-content m-1">
                        <p class="text-justify"><?php echo e($comment->comment); ?></p>
                      </div>
                      
                    </div>
                  </div>
                  
                </li>
              </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>


            <h3 class="utf-comments-heading add-comment">Add a Comment</h3>
            <!-- Comments Form Starts -->
            <div class="comments-form">
              <form method="POST" action="<?php echo e(route('frontend.portfolio.comments')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="form-group col-md-6 col-lg-6">
                      <input type="hidden" name="portfolio_id" class="form-control" value="<?php echo e($portfolio->id); ?>">
                      <input type="text" name="viewer_name" class="form-control" placeholder="Name" required>
                    </div>
                    <div class="form-group col-md-6 col-lg-6">
                      <input type="email" name="viewer_email" class="form-control" placeholder="Email" required>
                    </div>
                    <div class="form-group col-md-12 col-lg-12">
                      <textarea name="comment" class="form-control" placeholder="Comment..." required></textarea>
                    </div>
                    <div class="col-12 submit-form">
                      <button class="mx-auto btn" type="submit"><span>Submit Comment</span></button>
                    </div>
                  </div>
              </form>
            </div>
            <!-- Comments Form Ends -->
          </div>
        </article>
        <!-- Article Ends -->
      </div>
    </div>
  </div>
  <!-- Main Content Ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\101-Projects\porto\resources\views/frontend/portfolio-single.blade.php ENDPATH**/ ?>